/*
 ============================================================================
 Name        : image_fir.h
 Author      : Milica Stojiljkovic and Marko Kostic
 Version     : 1.0
 Description :
 Date        : 15.1.2016.
 ============================================================================
 */

#ifndef __IMAGE_FIR__
#define __IMAGE_FIR__

typedef struct {
	uint32_t height;
	uint32_t width;
	uint8_t *pixels;
	uint32_t size;
} input_image_t;

typedef struct {
	uint32_t height;
	uint32_t width;
	int16_t *pixels;
	uint32_t size;
} output_image_t;

typedef struct {
	uint16_t order;
	int16_t *pixels;
	uint16_t size;
} coeficients_t;

#define NUM_COEF (7)

void init_coef_from_file(coeficients_t *coef, const char *file_name);
void init_image_from_file(input_image_t *image, const char *file_name);
void write_image_to_file(output_image_t *image, uint32_t width, uint32_t height);
void init_input_image(input_image_t *image, uint32_t width, uint32_t height);
void init_output_image(output_image_t *image, uint32_t width, uint32_t height);
uint8_t *get_input_pixel(input_image_t *image, uint16_t row, uint16_t column);
int16_t *get_output_pixel(output_image_t *image, uint16_t row, uint16_t column);
int16_t *get_coef(coeficients_t *coef, uint16_t row, uint16_t column);
void copy_row(input_image_t *image, uint16_t dest, uint16_t src);
void copy_column(input_image_t *image, uint16_t dest, uint16_t src);
void copy_block(input_image_t *dest, input_image_t *src, uint16_t row,
		uint16_t column);
void expand_image(input_image_t *image, uint8_t n);
void fir_filter(input_image_t *in_image, output_image_t *out_image,
		coeficients_t *coef, uint8_t n);

#endif
